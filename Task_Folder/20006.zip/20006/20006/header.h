#define _CRT_SECURE_NO_WARNINGS
#define _HEADER_H_
#pragma once


char player_name[17], char_team[300][300][17], char_temp[17];
int player_num, team_num, player_level, int_team[300][300],
team_cnt, team_idx[300], i, j, k, check, int_temp;