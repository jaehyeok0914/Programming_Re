#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include "header.h"

void input(player_num, team_num);
void copy();
void output();

int main(void) {


    scanf("%d %d", &player_num, &team_num);
    input(player_num, team_num);
    copy();
    output();
    return 0;
}